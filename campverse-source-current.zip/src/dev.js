import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here=dirname(fileURLToPath(import.meta.url)), dataDir=join(here,'..','data');
mkdirSync(dataDir,{recursive:true});
const dbPath=process.env.CAMPVERSE_DEV_DB||join(dataDir,'campverse-dev.sqlite');
const keyPath=join(dataDir,'dev-jwt.key');
let secret;
try{secret=readFileSync(keyPath)}catch{secret=randomBytes(48);writeFileSync(keyPath,secret,{mode:0o600,flag:'wx'})}
const db=new DatabaseSync(dbPath);
db.exec(`PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS universities(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,city TEXT,state TEXT,listing_status TEXT NOT NULL DEFAULT 'pending');
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,username TEXT NOT NULL UNIQUE,full_name TEXT NOT NULL,university_id INTEGER REFERENCES universities(id),role TEXT NOT NULL DEFAULT 'student',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY,author_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,body TEXT NOT NULL,visibility TEXT NOT NULL DEFAULT 'public',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS likes(post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY,reporter_id INTEGER NOT NULL REFERENCES users(id),target_type TEXT NOT NULL,target_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS admission_verifications(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),private_object_key TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);`);

const json=(res,status,data)=>{const text=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(text),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(text)};
const limits=new Map();
function rateLimit(req){const key=req.socket.remoteAddress||'local',now=Date.now(),old=limits.get(key)||{start:now,count:0};if(now-old.start>60_000){old.start=now;old.count=0}old.count++;limits.set(key,old);return old.count<=120}
function tokenFor(user){const payload=Buffer.from(JSON.stringify({sub:user.id,role:user.role,exp:Math.floor(Date.now()/1000)+7*86400})).toString('base64url'),head=Buffer.from('{"alg":"HS256","typ":"JWT"}').toString('base64url'),input=`${head}.${payload}`,sig=createHmac('sha256',secret).update(input).digest('base64url');return `${input}.${sig}`}
function userFrom(req){const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'').split('.');if(token.length!==3) return null;const input=`${token[0]}.${token[1]}`,sig=createHmac('sha256',secret).update(input).digest(),given=Buffer.from(token[2],'base64url');if(given.length!==sig.length||!timingSafeEqual(given,sig))return null;try{const payload=JSON.parse(Buffer.from(token[1],'base64url').toString());if(payload.exp<Date.now()/1000)return null;const row=db.prepare('SELECT id,email,username,full_name,university_id,role FROM users WHERE id=?').get(payload.sub);return row||null}catch{return null}}
async function readBody(req){let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>1_000_000)throw Object.assign(new Error('Request body is too large'),{status:413})}try{return JSON.parse(text||'{}')}catch{throw Object.assign(new Error('Request body must be valid JSON'),{status:400})}}
const server=createServer(async(req,res)=>{
  const origin=req.headers.origin;
  if(origin&&/^https?:\/\/(localhost|127\.0\.0\.1):5173$/.test(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin')}
  res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
  if(!rateLimit(req))return json(res,429,{error:'Too many requests. Try again shortly.'});
  const url=new URL(req.url||'/',`http://${req.headers.host||'127.0.0.1'}`);
  try{
    if(req.method==='GET'&&url.pathname==='/api/health')return json(res,200,{ok:true,database:'sqlite-dev',path:dbPath});
    if(req.method==='GET'&&url.pathname==='/api/universities')return json(res,200,db.prepare("SELECT id,name,city,state FROM universities WHERE listing_status='approved' ORDER BY name").all());
    if(req.method==='GET'&&url.pathname==='/api/posts'){const rows=db.prepare(`SELECT p.id,p.body,p.created_at,u.username,u.full_name,uni.name university,(SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes FROM posts p JOIN users u ON u.id=p.author_id LEFT JOIN universities uni ON uni.id=u.university_id WHERE p.visibility='public' ORDER BY p.created_at DESC LIMIT 50`).all();return json(res,200,rows)}
    if(req.method==='POST'&&url.pathname==='/api/auth/register'){
      const b=await readBody(req),email=String(b.email||'').trim().toLowerCase(),username=String(b.username||'').trim().toLowerCase(),fullName=String(b.fullName||'').trim(),password=String(b.password||'');
      if(!/^\S+@\S+\.\S+$/.test(email)||password.length<10||fullName.length<2||fullName.length>120||!/^[a-z0-9_]{3,24}$/.test(username))return json(res,400,{error:'Use a valid email, password of at least 10 characters, full name and username of 3–24 letters, numbers or underscores.'});
      const salt=randomBytes(16),actual=scryptSync(password,salt,64),encoded=`${salt.toString('hex')}:${actual.toString('hex')}`;
      try{const result=db.prepare('INSERT INTO users(email,password_hash,username,full_name,university_id) VALUES(?,?,?,?,?)').run(email,encoded,username,fullName,b.universityId||null);const user=db.prepare('SELECT id,email,username,full_name,university_id,role FROM users WHERE id=?').get(result.lastInsertRowid);return json(res,201,{user,token:tokenFor(user)})}catch(e){if(String(e.code).startsWith('SQLITE_CONSTRAINT'))return json(res,409,{error:'Email or username is already in use'});throw e}
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/login'){
      const b=await readBody(req),email=String(b.email||'').trim().toLowerCase(),row=db.prepare('SELECT id,email,password_hash,username,full_name,university_id,role FROM users WHERE email=?').get(email);
      if(!row)return json(res,401,{error:'Email or password is incorrect'});const [saltHex,hashHex]=row.password_hash.split(':');const actual=scryptSync(String(b.password||''),Buffer.from(saltHex,'hex'),64),expected=Buffer.from(hashHex,'hex');if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return json(res,401,{error:'Email or password is incorrect'});delete row.password_hash;return json(res,200,{user:row,token:tokenFor(row)});
    }
    if(req.method==='POST'&&url.pathname==='/api/posts'){
      const user=userFrom(req);if(!user)return json(res,401,{error:'Sign in required'});const b=await readBody(req),body=String(b.body||'').trim();if(!body||body.length>5000)return json(res,400,{error:'Post must contain 1 to 5000 characters'});const result=db.prepare('INSERT INTO posts(author_id,body) VALUES(?,?)').run(user.id,body);const post=db.prepare('SELECT id,body,created_at FROM posts WHERE id=?').get(result.lastInsertRowid);return json(res,201,post);
    }
    const likeMatch=url.pathname.match(/^\/api\/posts\/(\d+)\/likes$/);
    if(req.method==='POST'&&likeMatch){const user=userFrom(req);if(!user)return json(res,401,{error:'Sign in required'});try{db.prepare('INSERT INTO likes(post_id,user_id) VALUES(?,?)').run(Number(likeMatch[1]),user.id);return json(res,201,{liked:true})}catch(e){if(String(e.code).startsWith('SQLITE_CONSTRAINT'))return json(res,409,{error:'Post is missing or already liked'});throw e}}
    if(req.method==='POST'&&url.pathname==='/api/reports'){const user=userFrom(req);if(!user)return json(res,401,{error:'Sign in required'});const b=await readBody(req);if(!['post','user','comment'].includes(b.targetType)||!b.targetId||!b.reason)return json(res,400,{error:'Provide a valid target and reason'});db.prepare('INSERT INTO reports(reporter_id,target_type,target_id,reason) VALUES(?,?,?,?)').run(user.id,b.targetType,String(b.targetId),String(b.reason).slice(0,1000));return json(res,201,{received:true})}
    return json(res,404,{error:'Route not found'});
  }catch(e){return json(res,e.status||500,{error:e.status?e.message:'Request failed'})}
});
const port=Number(process.env.PORT||4000);server.listen(port,'127.0.0.1',()=>console.log(`CAMPVERSE development API listening on http://127.0.0.1:${port} (${dbPath})`));
